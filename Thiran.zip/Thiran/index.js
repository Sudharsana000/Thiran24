const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const routes = require('./Routes/routes');

require('dotenv').config();


const { MONGO_URL, PORT } = process.env;
mongoose
  .connect(MONGO_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    const app = express();
    app.set('view engine', 'ejs');
    app.use(express.static('Public'));

    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.json());

    app.use('/', routes);

    app.listen(PORT, () => {
      console.log(`Server is listening on http://localhost:${PORT}`);
    });

  })
  .catch((err) => 
    console.error('MongoDb connection error:', err)
  );
