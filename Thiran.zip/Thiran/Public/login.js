function handleLogin(){
    const Email = document.getElementById('email').value
    const postData = {
        // Add your login data here, for example:
        email: document.getElementById('email').value,
        password: document.getElementById('password').value
    };

    // Options for the fetch request
    const options = {
        method: 'POST', 
        headers: {
            'Content-Type': 'application/json' 
        },
        body: JSON.stringify(postData) 
    };

    fetch("/login", options) 
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        window.location.href = '/';
        sessionStorage.setItem("email",Email)
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
}