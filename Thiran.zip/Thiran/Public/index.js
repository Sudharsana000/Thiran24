function redirectToEvent(event_name) {
    // Construct the URL with the variable value
    var url = '/events?variable=' + encodeURIComponent(event_name);
    
    // Redirect to the URL
    window.location.href = url;
}