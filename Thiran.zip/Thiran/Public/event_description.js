events = {
    "Event 1": {
        title: "Algocode",
    },
    "Event 2": {
        title: "Alcohol",
    }
}

function onLoad(event_name){
    const title = events[event_name]["title"]
    document.getElementById("event_title").innerHTML = title
}

function registerEvent(){
    const email = sessionStorage.getItem("email")

    if(!email){
        window.location.href = '/login';
    }
    else{
        
    }
}