function handlesignup(){
    const postData = {
        // Add your login data here, for example:
        username: document.getElementById('username').value,
        email: document.getElementById('email').value,
        password: document.getElementById('password').value
    };

    // Options for the fetch request
    const options = {
        method: 'POST', // Specify the method as POST
        headers: {
            'Content-Type': 'application/json' // Specify content type as JSON
        },
        body: JSON.stringify(postData) // Convert data to JSON string and send in the body
    };

    fetch("/signup", options)
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text(); 
    })
    .then(data => {
        alert(data);
        window.location.href = '/login';
    })
    .catch(error => {
        // Handle errors
        console.error('There was a problem with the fetch operation:', error);
        alert("Error: " + error.message);
    });
}