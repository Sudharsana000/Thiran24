const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../Models/User');


exports.renderLogin = async(req, res) => {
    res.render('login')
}

exports.login = async(req, res) => {
    const { email, password } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (!existingUser) {
            return res.status(404).send('Account not found');
        }

        // Verify the password
        const passwordMatch = await bcrypt.compare(password, existingUser.password);
        if (!passwordMatch) {
            return res.status(401).send('Incorrect password');
        }

        res.status(200).send('Login successful');
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).send('An error occurred during login');
    }
}

exports.rendersignup = async(req,res) =>{
    res.render('signup');
}

exports.signup = async(req,res) =>{
    const { username, email, password } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send('Email already exists');
        }
        // Create a new user
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();
        res.status(200).send('User registered successfully');
    } catch (error) {
        console.error('Error during signup:', error);
        res.status(500).send('An error occurred during signup');
    }
}