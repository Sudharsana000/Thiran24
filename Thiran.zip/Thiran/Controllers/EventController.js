const express = require('express');


exports.describeEvent = async(req, res) => {
    var event_name = req.query.variable
    res.render('event_description', {event_name})
}