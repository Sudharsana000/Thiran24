const express = require('express');
const router = express.Router();
const eventController = require('../Controllers/EventController');
const signup_loginController = require('../Controllers/SignupLoginController');

router.get('/', (req, res) =>{
    res.render('index')
})

router.get('/events', eventController.describeEvent)

router.get('/login', signup_loginController.renderLogin)
router.post('/login', signup_loginController.login)

router.get('/signup',signup_loginController.rendersignup)
router.post('/signup',signup_loginController.signup)

module.exports = router;